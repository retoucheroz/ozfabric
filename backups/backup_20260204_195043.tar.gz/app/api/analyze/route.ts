import { NextRequest, NextResponse } from "next/server";
import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from "@google/generative-ai";

export async function POST(req: NextRequest) {
    try {
        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey) {
            return NextResponse.json({ error: "GEMINI_API_KEY is not configured" }, { status: 500 });
        }

        const body = await req.json();
        const { image, images, language, type = 'techPack', workflowType } = body; // type: 'techPack' | 'pose'

        if (!image && (!images || !Array.isArray(images) || images.length === 0)) {
            return NextResponse.json({ error: "Image or images array required" }, { status: 400 });
        }

        const genAI = new GoogleGenerativeAI(apiKey);

        // Prioritize Gemini 2.0 Flash Lite for all analysis tasks as requested
        let modelsToTry = [
            "gemini-2.0-flash-lite",
            "gemini-2.0-flash",
            "gemini-1.5-flash"
        ];

        if (type === 'techPack' || type === 'fabric' || type === 'fit' || type === 'pose') {
            // User Request: Use 2.0 Flash Lite/Flash for all technical tasks
            modelsToTry = [
                "gemini-2.0-flash-lite",
                "gemini-2.0-flash",
                "gemini-1.5-flash"
            ];
        }

        let analysis = null;
        let usedModel = "";
        const errors: string[] = [];

        // Pre-process images
        const inputImages = images && Array.isArray(images) ? images : [image];
        const processedImages = inputImages.map((img: string) => {
            let base64Data = img;
            let mimeType = "image/png";
            if (img.includes(",")) {
                const parts = img.split(",");
                const match = parts[0].match(/:(.*?);/);
                if (match) mimeType = match[1];
                base64Data = parts[1];
            }
            return {
                inlineData: {
                    data: base64Data,
                    mimeType: mimeType
                }
            };
        });

        for (const modelName of modelsToTry) {
            try {
                const model = genAI.getGenerativeModel({
                    model: modelName,
                    generationConfig: { responseMimeType: "application/json" },
                    // Critical: Disable safety filters to prevent blocking fashion images
                    safetySettings: [
                        { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_NONE },
                        { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_NONE },
                        { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_NONE },
                        { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_NONE },
                    ]
                });

                // FORCE ENGLISH for TechPack, Fabric, Fit AND POSE analysis regardless of UI language. 
                // All AI prompts must be in English for best adherence.
                const langInstruction = (type === 'techPack' || type === 'fabric' || type === 'fit' || type === 'pose')
                    ? "RESPOND IN ENGLISH ONLY. TECHNICAL FASHION TERMINOLOGY."
                    : (language === "tr" ? "RESPOND IN TURKISH. Translate Technical Terms to professional Turkish fashion terminology." : "Respond in English.");

                let prompt = "";
                const multiImageContext = processedImages.length > 1 ? "You are shown multiple images of the same garment (front, back, details). Analyze them collectively for a single accurate description." : "";


                if (type === 'pose') {
                    prompt = `${langInstruction} ${multiImageContext} You are an expert Fashion Pose Director for AI Image Generation.
                    Your task is to describe the pose in this image with EXTREME PRECISION so that an AI can replicate it EXACTLY without seeing the image.
                    
                    ANALYZE THESE SPECIFIC POINTS:
                    1. HEAD & EYES: Exact head tilt and facing direction. Where are eyes looking?
                    2. SHOULDERS & TORSO: Body angle relative to camera (front, 3/4, side). Leaning forward/back? Shoulders lifted or relaxed?
                    3. ARMS & HANDS (CRITICAL): Precise position of EACH arm. Elbow bend angles. Hand gestures (in pockets, crossed, holding object, touching face).
                    4. LEGS & FEET: Stance width. Weight distribution (on which leg?). Knee bends. Crossed legs?
                    5. MOVEMENT & HAIR DYNAMICS (CRITICAL):
                       - Is it static or dynamic (walking, running, jumping, turning)?
                       - IMPORTANT: Describe the HAIR MOVEMENT based on the body motion. 
                       - If static technical angle (front, side, back): Hair should be neat, sleek, and static.
                       - If dynamic/styling pose (walking, mid-step, turning): Describe the hair flow, momentum, and movement (e.g., "hair is flowing naturally with the movement", "loose strands showing motion", "hair is swinging slightly to the side"). 
                       - FOR FEMALE MODELS: Pay extreme attention to long hair behavior during movement to avoid a static appearance.
                    
                    OUTPUT REQUIREMENTS:
                    - Create a dense, instructional paragraph starting with "Model is...".
                    - Include hair dynamics: "Hair is [described movement]".
                    - Use anatomical terms if helpful (e.g. "hands akimbo").
                    - DISREGARD clothing details. Focus ONLY on biomechanics, posture, and hair dynamics.
                    
                    JSON Response Format:
                    {
                        "description": "Full detailed instructional prompt describing the pose and hair movement."
                    }`;
                } else {
                    // TECH PACK MODE - Fabric & Detail Analysis
                    const workflowStr = workflowType || 'upper'; // Default to upper if not provided

                    prompt = `${langInstruction} ${multiImageContext} You are a Textile Expert analyzing fabric details for AI image generation. 
                    
                    CURRENT WORKFLOW: This generation is for a ${workflowStr.toUpperCase()} garment.
                    
                    ANALYZE THE IMAGES PROVIDED:
                    1. IDENTIFY THE MAIN PRODUCT: Focus most of your detail on the garment matching the ${workflowStr.toUpperCase()} workflow.
                    2. ANALYZE FABRIC (MAIN ONLY): What is the main material? Texture? Pattern? Color? Finish?
                    3. ANALYZE FIT (MAIN ONLY): Describe overall cut and silhouette.
                    4. SECONDARY PRODUCTS (LAYERING): If you see other garments (e.g. if main is BOTTOM, look for TOP or INNER WEAR):
                       - Describe them EXTREMELY BRIEFLY (e.g., "White cotton shirt", "Black sleeveless top"). 
                       - DO NOT give technical details for secondary items.
                    
                    JSON Response Requirements:
                    - "visualPrompt": Detailed description of the MAIN ${workflowStr} garment (ONE paragraph).
                    - "productName": Generic English name for the MAIN garment.
                    - "fitDescription": Detailed fit for the MAIN garment.
                    - "upperBrief": A very brief description (3-5 words) of the TOP/OUTER garment if present and NOT the main item. Else null.
                    - "lowerBrief": A very brief description (3-5 words) of the BOTTOM garment if present and NOT the main item. Else null.
                    - "innerBrief": A very brief description (3-5 words) of the INNER/BASE layer garment if present. Else null.
                    - "shoesBrief": A very brief description (3-5 words) of the footwear if present. Else null.
                    - "closureType": buttons OR zipper OR none für the MAIN garment.
                    
                    JSON Response:
                    {
                        "visualPrompt": "...",
                        "productName": "...",
                        "fitDescription": "...",
                        "upperBrief": "...",
                        "lowerBrief": "...",
                        "innerBrief": "...",
                        "shoesBrief": "...",
                        "fabric": { "main": "...", "finish": "..." },
                        "pattern": "...",
                        "colors": "...",
                        "closureType": "..."
                    }`;
                }

                // FIT/PATTERN ANALYSIS for ALL GARMENTS - shirts, jackets, pants, etc.
                if (type === 'fit') {
                    prompt = `${langInstruction} ${multiImageContext} You are an EXPERT Garment Pattern & Fit Analyst. Your analysis will be used to recreate this EXACT fit in AI image generation. BE EXTREMELY PRECISE about silhouette details.

                    FIRST: Identify the garment type:
                    - Is it a TOP (shirt, blouse, t-shirt, sweater, jacket, coat)?
                    - Is it a BOTTOM (pants, jeans, trousers, shorts, skirt)?

                    FOR TOP GARMENTS (Shirt/Jacket/Coat/Sweater):
                    1. FIT TYPE: Slim-fit, Regular-fit, Relaxed-fit, Oversized
                    2. SHOULDER: Natural shoulder, Dropped shoulder, Structured shoulder
                    3. CHEST/BODY: Fitted, Comfortable, Loose, Boxy
                    4. SLEEVE LENGTH: Short, 3/4, Long
                    5. SLEEVE FIT: Fitted, Regular, Wide
                    6. HEM LENGTH: Cropped, Hip-length, Mid-thigh, Long
                    7. COLLAR/NECKLINE TYPE: Point collar, Spread collar, Mandarin, V-neck, Crew, etc.
                    8. CLOSURE: Button-front, Zip, Pullover

                    FOR BOTTOM GARMENTS (Pants/Jeans/Shorts) - BE EXTREMELY DETAILED:
                    1. FIT TYPE: Skinny, Slim, Slim-tapered, Regular/Straight, Relaxed, Wide-leg, Bootcut, Mom-fit, Baggy, Oversized-Baggy, Tapered-Leg, High-Waisted, High-Waisted-Baggy, High-Waisted-Tapered
                    2. RISE: Low-rise, Mid-rise, High-rise, Extreme High-rise (waistband position relative to navel)
                    3. HEM LENGTH (CRITICAL FOR NANO BANANA): 
                       - Floor-length: Touching the floor, covering shoes.
                       - Full-length: Hitting the floor but not pooling.
                       - Ankle-length: Precise hit at the ankle bone.
                       - Cropped: 2-4 inches above the ankle.
                       - Culotte: Mid-calf.
                    4. THIGH FIT (CRITICAL): 
                       - Is it TIGHT against the thigh (like leggings)?
                       - FITTED (follows shape but not tight)?
                       - COMFORTABLE (some room)?
                       - LOOSE/RELAXED (visible ease)?
                       - VERY LOOSE (baggy at thigh)?
                    5. KNEE AREA: Does the pant fit snug at knee, or is there room?
                    6. LEG SHAPE & TAPER (VERY CRITICAL):
                       - STRAIGHT: Same width from thigh to ankle, NO taper.
                       - TAPERED: Where does taper BEGIN? (From hip? From knee? From mid-calf?)
                       - How MUCH taper? (Minor 10%, Moderate 25%, Significant 40%+)
                    7. LEG OPENING / ANKLE (CRITICAL):
                       - VERY NARROW (skinny, less than 14cm)
                       - NARROW (slim, 14-16cm)
                       - STANDARD (regular, 17-19cm)
                       - WIDE (relaxed, 20-22cm)
                       - VERY WIDE (wide-leg, 23cm+)
                    8. FABRIC BEHAVIOR: Does it STACK at the ankle? Puddle on the floor? Bunches at knee? Clean straight lines?
                    9. OVERALL PROPORTION: How does the garment relate to body proportions in the image?
                    
                    CRITICAL: If the pants appear WIDER or LOOSER than typical slim-fit jeans, EXPLICITLY STATE THIS. If they are NARROWER or TIGHTER than typical straight-leg, STATE THIS. Use combinations like "High-Waisted Baggy Tapered-Leg".

                    OUTPUT: Generate a PRECISE, PROMPT-READY fit description. Include ALL relevant details.

                    Examples:
                    - Shirt: "Regular-fit cotton shirt with natural shoulders, comfortable body fit, long sleeves with standard cuff. Point collar. Hip-length hem."
                    - Baggy Pants: "Extreme High-Waisted Baggy Tapered-Leg pants. Loose thigh fit, significant taper beginning from the knee. Narrow leg opening at the ankle. Floor-length hem with slight pooling/stacking."
                    - Regular Straight: "Mid-rise regular straight-leg jeans. Comfortable thigh fit, NO taper, consistent width from thigh to ankle. Standard leg opening. Full-length hem hitting the top of the shoes."

                    JSON Response:
                    {
                        "fitDescription": "Complete prompt-ready fit description with ALL silhouette details",
                        "garmentType": "Top / Bottom",
                        "fitType": "Specific combination (e.g., High-Waisted Baggy Tapered-Leg)",
                        "keyFeatures": "Most important silhouette characteristics",
                        "silhouetteNotes": "Additional visual notes for AI reproduction - include WHERE garment is tight vs loose",
                        "proportionNotes": "How the garment appears relative to body - is it WIDER or NARROWER than typical? Be explicit about lengths."
                    }`;
                }

                const result = await model.generateContent([
                    prompt,
                    ...processedImages
                ]);

                let responseText = result.response.text();
                responseText = responseText.replace(/```json/g, "").replace(/```/g, "").trim();

                if (type === 'pose') {
                    analysis = { description: responseText }; // Wrap plain text in object
                } else {
                    analysis = JSON.parse(responseText);
                }
                usedModel = modelName;
                break; // Success

            } catch (error) {
                console.warn(`Model ${modelName} failed:`, (error as Error).message);
                errors.push((error as Error).message);
            }
        }

        if (!analysis) {
            console.error("All models failed:", errors);
            // Return detailed error so user knows if it's Quota or API Key issue
            return NextResponse.json({ error: "Analysis failed. Details: " + errors.join(" | "), details: errors }, { status: 500 });
        }

        return NextResponse.json({
            status: "success",
            data: analysis,
            modelUsed: usedModel
        });

    } catch (error) {
        console.error("Analysis API Error:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}
