import { NextRequest, NextResponse } from "next/server";

// Configure route config
export const maxDuration = 60; // 60 seconds max duration
export const dynamic = 'force-dynamic';

// Negative prompts for common issues
const NEGATIVE_PROMPTS = {
    shoes: "oversized shoes, chunky shoes, large footwear, clown shoes, big shoes, thick soles, platform shoes, bulky sneakers, exaggerated footwear, disproportionate shoes, cartoon shoes, huge feet, giant shoes, massive sneakers, wide shoes, puffy shoes, oversized feet, unrealistic shoe size, shoes too big for body, exaggerated shoe proportions",
    buttons: "open shirt, unbuttoned, open front, chest visible",
    tucked: "tucked in shirt, shirt inside pants, waistband visible",
    untucked: "untucked shirt, loose hem, shirt over pants, hidden waistband, long shirt hanging out", // NEW negative
    flatFabric: "flat fabric, smooth texture, plain surface, digital print look, no texture, solid color fabric, printed stripes, screen print, no weave visible, uniform surface, plastic looking fabric",
    cropping: "cropped head, cut off head, missing head, partial face, close up, zoomed in, out of frame, cropped feet, missing shoes",
    wind: "strong wind hair, messy hair, disheveled hair, chaotic strands",
    equipment: "studio lighting equipment, softbox, flash, umbrella, reflector, camera tripod, photography gear, studio lamps, light stand, visible equipment",
    distorted_logo: "text, logo, branding, writing, watermark, signature, letters, words, print on back, brand name, typography"
};

const EXPRESSIONS = [
    "Expression: calm confident neutral, slight squinch (lower eyelids gently raised), lips softly closed, tiny asymmetry (one mouth corner ~2% higher), relaxed brows.",
    "Expression: friendly-neutral, micro-smile only in one corner, jaw relaxed, cheeks subtly lifted, eyes engaged not wide.",
    "Expression: serious with intention, micro-squint, lips very lightly pressed (not tight), one brow a touch lower, no frown lines.",
    "Expression: subtle curiosity, inner brows slightly raised, lips parted 1–2 mm, eyes alert but soft, no exaggerated smile.",
    "Expression: thoughtful neutral, gaze steady, eyelids relaxed, lips gently together with a slight lower-lip softness, mild brow knit (very subtle).",
    "Expression: warm and professional, faint micro-smile, slight squinch, eyebrows relaxed (not arched), calm eyes.",
    "Expression: barely playful, one mouth corner curls up slightly, eyes soften, no teeth, keep it understated and natural.",
    "Expression: tiny smirk (only one corner), micro-squint, chin neutral, keep symmetry imperfect and realistic.",
    "Expression: calm intensity, lower eyelids slightly tightened, lips neutral, minimal brow tension, ‘present’ look (not blank).",
    "Expression: relaxed neutral, slight asymmetry in brows and mouth, gentle squinch, avoid frozen lips and perfectly mirrored features."
];

const GAZES = [
    "Gaze: looking directly into the camera lens, eyes centered in the sockets, engaged.",
    "Gaze: looking at a point just to the right of the lens (tiny offset), eyes still centered, calm.",
    "Gaze: looking at a point just to the left of the lens (tiny offset), soft focus, not wide-eyed.",
    "Gaze: looking slightly above the lens (a few degrees), then settle back to neutral, composed.",
    "Gaze: looking slightly below the lens (a few degrees), relaxed eyelids, subtle confidence.",
    "Gaze: looking past the camera as if noticing something near the lens, eyes not cranked to the side.",
    "Gaze: ‘face this way, eyes back to camera’ look—head stays angled, eyes return toward lens without showing too much white.",
    "Gaze: near-camera contact (at the camera edge), soft and friendly, eyes centered.",
    "Gaze: short ‘micro-shift’—eyes slightly off-lens but still forward, like a candid in-between moment.",
    "Gaze: calm ‘present’ stare—steady focus, no startled look, eyelids gently relaxed."
];

export async function POST(req: NextRequest) {
    try {
        const {
            productName,
            workflowType: requestedWorkflowType,
            uploadedImages,
            gender,
            prompt: customPrompt,
            poseFocus,
            resolution = "1K",
            aspectRatio = "3:4",
            isAngles,
            preview = false,
            poseDescription,
            buttonsOpen = false,
            tucked = false,
            closureType = 'buttons', // buttons, zipper, or none
            productDescription,
            fitDescription,
            upperGarmentDescription,
            lowerGarmentDescription,
            innerWearDescription,
            shoesDescription, // NEW
            poseStickman = null, // Receive stickman image URL
            detailView = 'front', // 'front' | 'angled' | 'back' for Detail Shots
            editedPrompt = null,
            targetView = null,
            hairBehindShoulders = false,
            lookAtCamera = true, // Default to true
            socksType = 'none', // 'none' | 'white' | 'black'
            enableWind = false, // NEW: Subtle airflow toggle
            isStylingShot = true, // NEW: Flag to identify styling
            lightingPositive = null, // NEW
            lightingNegative = null, // NEW
            seed = null, // NEW
            enableWebSearch = false, // NEW
            enableExpression = false, // NEW: Expression variation toggle
            enableGaze = false // NEW: Gaze variation toggle
        } = await req.json();

        // One-time random seed for consistency across angles
        const requestSeed = (seed !== null && seed !== undefined) ? Number(seed) : Math.floor(Math.random() * 1000000000);

        // === SAFETY: Ensure raw 'pose' image is NEVER included in input_images ===
        // We only use 'poseStickman' for pose control later.
        if (uploadedImages && uploadedImages.pose) {
            delete uploadedImages.pose;
        }

        // 1. Determine Workflow Type
        const lowerName = productName.toLowerCase();
        let workflowType = requestedWorkflowType || 'upper';

        const lowerKeywords = ['pantolon', 'şort', 'etek', 'tayt', 'jean', 'trousers', 'skirt', 'shorts', 'leggings', 'joggers', 'denim'];
        const fullBodyKeywords = ['elbise', 'tulum', 'romper', 'kaban', 'palto', 'trençkot', 'dress', 'jumpsuit', 'coat', 'gown'];
        const setKeywords = ['takım', 'pijama', 'eşofman takımı', 'bikini', 'set', 'suit'];

        if (setKeywords.some(k => lowerName.includes(k))) {
            workflowType = 'set';
        } else if (fullBodyKeywords.some(k => lowerName.includes(k))) {
            workflowType = 'dress';
        } else if (lowerKeywords.some(k => lowerName.includes(k))) {
            workflowType = 'lower';
        } else {
            workflowType = 'upper';
        }

        // === SYNC detailView with targetView for Batch Mode ===
        let activeDetailView = detailView;
        if (targetView && poseFocus === 'detail') {
            if (targetView === 'back') activeDetailView = 'back';
            else if (targetView === 'side') activeDetailView = 'angled';
            else activeDetailView = 'front';
        }

        // === HELPER: Build Asset List ===
        const buildAssetList = (view: string, imgs: any, focus: string, wfType: string): string[] => {
            const assets: string[] = [];

            // 1. Model always included
            if (imgs.model) assets.push(imgs.model);

            // Detail Assets Grouping
            const frontDetails = [imgs.detail_front_1, imgs.detail_front_2, imgs.detail_front_3, imgs.detail_front_4].filter(Boolean);
            const backDetails = [imgs.detail_back_1, imgs.detail_back_2, imgs.detail_back_3, imgs.detail_back_4].filter(Boolean);

            // 2. Garment Assets (Layering Logic)
            if (view === 'styling' || view === 'front') {
                if (imgs.main_product) assets.push(imgs.main_product);
                if (imgs.top_front) assets.push(imgs.top_front);
                if (imgs.bottom_front && focus !== 'closeup') assets.push(imgs.bottom_front);
                if (imgs.dress_front) assets.push(imgs.dress_front);
                if (imgs.jacket) assets.push(imgs.jacket);
                // Details (Front only for front views)
                assets.push(...frontDetails);
            } else if (view === 'side') {
                if (imgs.main_product) assets.push(imgs.main_product);
                if (imgs.top_front) assets.push(imgs.top_front);
                if (imgs.bottom_front) assets.push(imgs.bottom_front);
                if (imgs.dress_front) assets.push(imgs.dress_front); // Include dress in side view
                if (imgs.jacket) assets.push(imgs.jacket);
                if (imgs.backRefUpload) assets.push(imgs.backRefUpload);
                // Details (All for side views)
                assets.push(...frontDetails);
                assets.push(...backDetails);
            } else if (view === 'back') {
                if (imgs.top_back) assets.push(imgs.top_back);
                else if (imgs.top_front) assets.push(imgs.top_front);

                if (imgs.bottom_back) assets.push(imgs.bottom_back);
                else if (imgs.bottom_front) assets.push(imgs.bottom_front);

                if (imgs.jacket) assets.push(imgs.jacket);
                if (imgs.backRefUpload) assets.push(imgs.backRefUpload);
                // Details (Back only for back views)
                assets.push(...backDetails);
            }

            // 3. Shoes (Include if styling shot OR full/lower focus)
            if (imgs.shoes && (isStylingShot || (focus !== 'upper' && focus !== 'closeup'))) {
                assets.push(imgs.shoes);
            }

            // 4. Common Assets
            if (imgs.background) assets.push(imgs.background);
            if (imgs.inner_wear) assets.push(imgs.inner_wear);
            if (imgs.belt) assets.push(imgs.belt);
            if (imgs.hat) assets.push(imgs.hat);
            if (imgs.bag) assets.push(imgs.bag);
            if (imgs.glasses) assets.push(imgs.glasses);

            // 5. POSE REFERENCE (Stickman)
            // If stickman exists, we include it as an asset because it's clean and won't leak texture.
            if (poseStickman) {
                assets.push(poseStickman);
            }
            // Note: We still exclude original 'imgs.pose' to avoid leakage.

            // 6. DETAIL SHOT - SPECIAL ASSET FILTERING
            if (focus === 'detail') {
                // Clear previous assets and rebuild STRICTLY
                assets.length = 0;
                if (imgs.model) assets.push(imgs.model);
                if (imgs.background) assets.push(imgs.background);

                if (activeDetailView === 'front') {
                    // STRICT FRONT: Front assets + Front details
                    if (imgs.main_product) assets.push(imgs.main_product);
                    if (imgs.top_front) assets.push(imgs.top_front);
                    if (imgs.bottom_front) assets.push(imgs.bottom_front);
                    if (imgs.dress_front) assets.push(imgs.dress_front);
                    if (imgs.inner_wear) assets.push(imgs.inner_wear);
                    assets.push(...frontDetails);
                } else if (activeDetailView === 'back') {
                    // STRICT BACK: Back assets + Back details
                    if (imgs.top_back) assets.push(imgs.top_back);
                    if (imgs.bottom_back) assets.push(imgs.bottom_back);
                    if (imgs.backRefUpload) assets.push(imgs.backRefUpload);
                    assets.push(...backDetails);
                } else {
                    // ANGLED: All assets + All details
                    if (imgs.main_product) assets.push(imgs.main_product);
                    if (imgs.top_front) assets.push(imgs.top_front);
                    if (imgs.bottom_front) assets.push(imgs.bottom_front);
                    if (imgs.dress_front) assets.push(imgs.dress_front);
                    if (imgs.top_back) assets.push(imgs.top_back);
                    if (imgs.bottom_back) assets.push(imgs.bottom_back);
                    if (imgs.backRefUpload) assets.push(imgs.backRefUpload);
                    if (imgs.inner_wear) assets.push(imgs.inner_wear);
                    assets.push(...frontDetails);
                    assets.push(...backDetails);
                }
            }

            return assets;
        };

        // 2. Build Structured Prompt JSON for each view
        const buildStructuredPrompt = (view: 'styling' | 'front' | 'side' | 'back') => {

            // === STRUCTURED PROMPT OBJECT ===
            const structuredPrompt: any = {
                intent: "Fashion e-commerce photography",

                subject: {
                    type: gender === 'male' ? 'male_model' : gender === 'female' ? 'female_model' : 'model',
                    identity: uploadedImages.model ? "match_provided_model_image" : "generic_fashion_model",
                    hair_behind_shoulders: hairBehindShoulders, // Explicit boolean
                    look_at_camera: lookAtCamera, // NEW: Explicit boolean
                    wind: (workflowType === 'upper' || workflowType === 'lower') && isStylingShot && enableWind
                },

                garment: {
                    name: productName,
                    type: workflowType,
                    fabric: productDescription,
                    fit: fitDescription,
                    closure_type: closureType
                },

                // LATEST ADDITION: Check if user provided an edited structured prompt (JSON)
                _is_user_edited: false,

                styling: {
                    buttons: buttonsOpen ? "open" : "closed",
                    tucked: tucked,
                    inner_wear: uploadedImages.inner_wear ? {
                        visible: true,
                        description: innerWearDescription
                    } : null,
                    layers: {
                        jacket: uploadedImages.jacket ? {
                            visible: true,
                            description: null // Add jacket analysis if needed later
                        } : null,
                        dress: !!uploadedImages.dress_front,
                        upper_garment: uploadedImages.top_front ? {
                            visible: true,
                            description: upperGarmentDescription
                        } : null,
                        bottom_garment: uploadedImages.bottom_front ? {
                            visible: true,
                            description: lowerGarmentDescription
                        } : null,
                    },
                    socks: socksType
                },

                accessories: {
                    shoes: (workflowType !== 'upper' || uploadedImages.shoes) ? {
                        style: shoesDescription || "slim low-profile sneakers",
                        size: "SMALL, thin, minimal, proportional to body - NOT chunky, NOT oversized"
                    } : null,
                    belt: uploadedImages.belt ? true : false,
                    hat: uploadedImages.hat ? true : false,
                    glasses: uploadedImages.glasses ? true : false,
                    bag: uploadedImages.bag ? true : false
                },

                pose: {
                    reference: null, // No image ref, only text
                    description: poseDescription, // Analyzed text description
                    dynamic: true
                },
                camera: {
                    shot_type: "full_body",
                    angle: view,
                    framing: "head_to_toe"
                },

                scene: {
                    background: uploadedImages.background ? "match_provided_background" : "clean_studio",
                    lighting: "soft_fashion_lighting"
                },

                // Removed duplicate pose block
            };

            // === JSON OVERRIDE CHECK ===
            // If the user provided an edited prompt that is actually valid JSON, 
            // merge it or replace the structured prompt entirely.
            if (editedPrompt && (editedPrompt.trim().startsWith('{') || editedPrompt.trim().startsWith('['))) {
                try {
                    const parsed = JSON.parse(editedPrompt);
                    // If it's the structured prompt format, merge it
                    if (parsed.intent || parsed.subject || parsed.garment) {
                        Object.assign(structuredPrompt, parsed);
                        structuredPrompt._is_user_edited = true;
                        console.log("Using USER-EDITED JSON structured prompt");
                    }
                } catch (e) {
                    // Not valid JSON or not our format, treat as plain text later
                }
            }

            // Only run baseline enrichment if NO user JSON was provided
            if (!structuredPrompt._is_user_edited) {
                // === ENRICH WITH ANALYSIS DATA ===
                // ... (existing enrichment logic) ...
            }


            // === SMART PRODUCT NAME OVERRIDE ===
            // If user typed specific keywords in product name, override the analysis
            let currentProductDesc = productDescription; // Use local variable

            if (!structuredPrompt._is_user_edited) {
                const nameLower = productName.toLowerCase();
                let descLower = currentProductDesc ? currentProductDesc.toLowerCase() : "";

                // 1. DENIM / JEANS Override
                if (nameLower.includes('denim') || nameLower.includes('jeans')) {
                    if (descLower.includes('twill') || descLower.includes('canvas')) {
                        // Force denim
                        currentProductDesc = currentProductDesc.replace(/twill/gi, "denim").replace(/canvas/gi, "denim");
                        // Add 'denim' if missing
                        if (!currentProductDesc.toLowerCase().includes('denim')) {
                            currentProductDesc = "Denim/Jean fabric. " + currentProductDesc;
                        }
                    }
                }

            }


            // Fabric/Texture from productDescription
            if (!structuredPrompt._is_user_edited) {
                if (currentProductDesc) {
                    let fabricInfo = currentProductDesc;
                    if (fabricInfo.includes("undefined") || fabricInfo.includes("null")) {
                        fabricInfo = fabricInfo.replace(/Texture:\s*undefined\.?/gi, "").replace(/Pattern:\s*undefined\.?/gi, "").replace(/undefined/gi, "");
                    }
                    if (fabricInfo.trim().length > 5) {
                        structuredPrompt.garment.fabric = fabricInfo.trim();
                    }
                }

                if (fitDescription && workflowType === 'lower') {
                    structuredPrompt.garment.fit = fitDescription;
                }
            }

            // === VIEW-SPECIFIC ADJUSTMENTS ===

            if (view === 'styling' || isStylingShot) {
                // Artistic mode
                structuredPrompt.pose.dynamic = true;
                if (poseStickman) {
                    structuredPrompt.pose.reference = "use stickman reference";
                }
            } else {
                // Technical angles (front, side, back)
                structuredPrompt.camera.angle = view as string;
                structuredPrompt.pose.dynamic = false;

                // Only provide technical reference if no specific pose description is provided
                if (!poseDescription) {
                    structuredPrompt.pose.reference = (view as string) === 'front' ? "standing straight, arms at sides" :
                        (view as string) === 'side' ? "profile view, natural stance" :
                            "back view, straight posture";
                }

                if (poseStickman) {
                    structuredPrompt.pose.reference = "use stickman reference";
                }

                // Framing Logic for Technical Angles
                if (poseFocus === 'closeup') {
                    // CLOSEUP: Face to chest framing
                    structuredPrompt.camera.shot_type = 'close_up';
                    structuredPrompt.camera.framing = 'chest_and_face';
                    structuredPrompt.accessories.shoes = null;
                } else if (workflowType === 'upper') {
                    structuredPrompt.camera.shot_type = 'cowboy_shot';
                    structuredPrompt.camera.framing = 'cowboy_shot';
                } else {
                    structuredPrompt.camera.shot_type = 'full_body';
                    structuredPrompt.camera.framing = 'head_to_toe';
                }
            }

            // === DETAIL SHOT OVERRIDE (applies to any view) ===
            if (poseFocus === 'detail') {
                structuredPrompt.camera.shot_type = 'close_up';
                structuredPrompt.camera.framing = 'waist_to_above_knees';
                structuredPrompt.accessories.shoes = null;

                // Remove hair info for detail shots
                delete structuredPrompt.subject.hair_behind_shoulders;
                delete structuredPrompt.subject.look_at_camera;

                // Ensure upper garment is visible for lower body detail shots
                if (workflowType === 'lower' && !structuredPrompt.styling.layers.upper_garment) {
                    structuredPrompt.styling.layers.upper_garment = {
                        visible: true,
                        description: "a fitted professional top"
                    };
                }
            }

            // === CONVERT TO TEXT PROMPT ===
            const textPrompt = convertStructuredToText(structuredPrompt, view, workflowType);

            // === BUILD NEGATIVE PROMPT ===
            let negativePrompt = "";
            if (structuredPrompt.accessories.shoes) {
                negativePrompt += NEGATIVE_PROMPTS.shoes;
            }
            if (!buttonsOpen) {
                negativePrompt += ", " + NEGATIVE_PROMPTS.buttons;
            }
            if (!tucked && workflowType === 'upper') {
                negativePrompt += ", " + NEGATIVE_PROMPTS.tucked;
            } else if (tucked) {
                negativePrompt += ", " + NEGATIVE_PROMPTS.untucked;
            }

            // ALWAYS add flatFabric negative prompt to enforce textured fabric
            negativePrompt += ", " + NEGATIVE_PROMPTS.flatFabric;
            negativePrompt += ", " + NEGATIVE_PROMPTS.equipment;

            if (workflowType !== 'upper') {
                negativePrompt += ", " + NEGATIVE_PROMPTS.cropping;
            }

            // Prevent hallucinated logos on back view if not explicitly requested
            if (view.includes('back') || structuredPrompt.camera.angle === 'back') {
                negativePrompt += ", " + NEGATIVE_PROMPTS.distorted_logo;
            }

            if (structuredPrompt.subject.wind) {
                negativePrompt += ", " + NEGATIVE_PROMPTS.wind;
            }

            // Add custom prompt OR use user-edited full prompt
            let finalPrompt = textPrompt;
            if (editedPrompt && !structuredPrompt._is_user_edited) {
                finalPrompt = editedPrompt;
            } else if (customPrompt) {
                finalPrompt += ` ${customPrompt}`;
            }

            // === ASSET FILTERING ===
            const activeAssets = buildAssetList(view, uploadedImages, poseFocus, workflowType);

            return {
                prompt: finalPrompt,
                negative_prompt: negativePrompt + (lightingNegative ? ", " + lightingNegative : ""),
                input_images: activeAssets,
                structured: structuredPrompt
            };
        };

        // === TEXT PROMPT CONVERTER ===
        function convertStructuredToText(sp: any, view: string, wf: string): string {
            const clean = (str: string) => str?.trim().replace(/\.+$/, "") || "";

            // === SPECIAL SIMPLIFIED PROMPT FOR DETAIL SHOTS ===
            if (sp.camera.framing === 'waist_to_above_knees' || view.includes('detail')) {
                const parts: string[] = [];
                parts.push("Close-Up fashion photography detail shot.");
                parts.push(`Focusing on the ${clean(sp.garment.name)}, framing is waist-to-knees.`);

                const stylingParts = [];
                if (sp.styling.tucked) stylingParts.push("tucked in");
                else stylingParts.push("untucked");

                if (sp.styling.buttons === 'open' && (sp.camera.angle !== 'back' && !view.includes('back'))) {
                    stylingParts.push("front is open and unbuttoned");
                }

                if (stylingParts.length > 0) {
                    parts.push(`Styling: ${stylingParts.join(", ")}.`);
                }

                const viewText = (sp.camera.angle === 'back' || view.includes('back')) ? "BACK view" : "FRONT view";
                parts.push(`Angle: ${viewText} of the garment.`);

                if (lightingPositive) {
                    parts.push(`Lighting: ${clean(lightingPositive)}.`);
                }

                parts.push("Background: Use the provided reference background images.");

                return parts.join(" ");
            }

            // === FULL VERSION FOR REGULAR SHOTS ===
            const sections: string[] = [];

            // 1. Core Atmosphere & Framing
            let intro = "High-end fashion e-commerce photography.";
            if (sp.camera.framing === 'head_to_toe') intro += " Full body head-to-toe shot.";
            else if (sp.camera.framing === 'cowboy_shot') intro += " Cowboy shot, waist up.";
            else if (sp.camera.framing === 'chest_and_face') intro += " Close-up shot from face to chest, focusing on upper body and collar area.";
            sections.push(intro);

            // 2. Subject & Pose
            let subjectInfo = `Subject is a ${sp.subject.type}`;
            if (sp.camera.angle === 'back' || view.includes('back')) subjectInfo += " seen from the BACK";
            else if (sp.camera.angle === 'side' || sp.camera.angle === 'angled' || view.includes('angled')) subjectInfo += " in a THREE-QUARTER ANGLED side view";
            else subjectInfo += " in a FRONT view";

            if (sp.pose.reference && sp.pose.reference.includes("stickman")) {
                subjectInfo += " Pose Reference: Use the provided stickman image to control the pose strictly.";
            }

            if (sp.pose.description) subjectInfo += `, pose is ${clean(sp.pose.description)}`;
            if (sp.pose.reference && !sp.pose.reference.includes("stickman")) subjectInfo += ` (Reference: ${clean(sp.pose.reference)})`;
            sections.push(subjectInfo + ".");

            // 3. Main Outfit (Garment, Fabric, Fit)
            let outfit = `Main Garment: ${clean(sp.garment.name)}.`;
            if (sp.garment.fabric) outfit += ` Fabric: ${clean(sp.garment.fabric)}.`;
            if (sp.garment.fit) outfit += ` Fit/Silhouette: ${clean(sp.garment.fit)}.`;
            sections.push(outfit);

            // 4. Styling & Layers
            const stylingItems = [];
            if (sp.styling.tucked) stylingItems.push("top is tucked into the waistband, waistband is fully visible");
            if (sp.styling.buttons === 'open') stylingItems.push("front is open and unbuttoned");

            if (sp.styling.layers.jacket?.visible) {
                const jacketDesc = clean(sp.styling.layers.jacket.description);
                stylingItems.push(`wearing a jacket over the main garment${jacketDesc ? ` (${jacketDesc})` : ""}`);
            }

            if (sp.styling.layers.upper_garment?.visible && wf === 'lower') {
                if (uploadedImages.top_front) {
                    stylingItems.push("wearing the provided top garment reference image");
                } else {
                    const upperDesc = clean(sp.styling.layers.upper_garment.description);
                    stylingItems.push(`wearing a ${upperDesc || 'top garment'} tucked in or as a layer`);
                }
            }

            if (sp.styling.layers.bottom_garment?.visible && wf === 'upper' && sp.camera.shot_type !== 'close_up') {
                if (uploadedImages.bottom_front) {
                    stylingItems.push("wearing the provided bottom garment reference image");
                } else {
                    const bottomDesc = clean(sp.styling.layers.bottom_garment.description);
                    stylingItems.push(`paired with ${bottomDesc || 'bottom garment'}`);
                }
            }

            if (sp.styling.inner_wear?.visible) {
                const innerDesc = clean(sp.styling.inner_wear.description);
                stylingItems.push(`base layer${innerDesc ? ` (${innerDesc})` : ""} is visible`);
            }

            if (stylingItems.length > 0) {
                sections.push("Styling: " + stylingItems.join(", ") + ".");
            }

            // 5. Accessories & Extras
            const extras = [];
            if (sp.accessories.shoes) {
                // Replace 'sneakers' with 'shoes' in footwear description for more formal tone if desired, or keep as user input.
                // User specifically requested: "sneaker demesin shoes desin"
                let style = clean(sp.accessories.shoes.style);
                style = style.replace(/sneakers?/gi, "shoes");

                const size = clean(sp.accessories.shoes.size);
                extras.push(`Footwear: ${style}${size ? ` (${size})` : ""}`);
            }
            if (sp.styling.socks && sp.styling.socks !== 'none') extras.push(`wearing ${sp.styling.socks} socks`);

            // Add glasses if available in uploaded assets
            if (sp.accessories?.glasses) {
                extras.push("Wearing the provided sunglasses");
            }

            if (extras.length > 0) sections.push(extras.join(", ") + ".");

            // 6. Lighting
            if (lightingPositive) {
                sections.push(`Lighting: ${clean(lightingPositive)}.`);
            } else if (sp.scene.lighting) {
                sections.push(`Lighting: ${clean(sp.scene.lighting)}.`);
            }

            // 7. Background
            sections.push("Background: Use the provided reference background images.");

            // 8. Hair & Face
            let hairFace = "";

            // Camera Contact Logic
            if (view.includes('back') || sp.camera.angle === 'back' || sp.pose.description?.toLowerCase().includes('back to camera')) {
                hairFace = "Model is looking away from the camera.";
            } else if (sp.subject.look_at_camera === true) {
                hairFace = "Model is making direct eye contact with the camera.";
            } else if (sp.subject.look_at_camera === false) {
                // Explicitly requested NOT to look at camera
                hairFace = "Model is looking slightly away from the camera, avoiding direct eye contact.";
            }

            // Hair Logic
            if (sp.subject.hair_behind_shoulders === true) {
                hairFace += " Hair is neatly placed BEHIND the shoulders and stays static.";
            } else {
                const poseText = (sp.pose.description || "").toLowerCase();
                const isDynamicPose = poseText.includes("walking") || poseText.includes("turning") || poseText.includes("step") || poseText.includes("dynamic") || poseText.includes("movement") || (sp.pose.dynamic && view === 'styling');

                if (isDynamicPose && !view.includes('front') && !view.includes('back') && !view.includes('side')) {
                    hairFace += " Hair Dynamics: Physically accurate hair physics with soft strands flowing in the direction of motion, avoiding a static look.";
                } else {
                    hairFace += " Hair: Natural and well-groomed.";
                }
            }

            if (sp.subject.wind) {
                hairFace += " Add a very subtle studio airflow so the hair has gentle movement with soft flyaway strands.";
            }

            // 9. Expressions & Gaze (Only for styling shots)
            if (isStylingShot && !view.includes('back') && !view.includes('detail')) {
                if (enableExpression) {
                    const randomExpression = EXPRESSIONS[Math.floor(Math.random() * EXPRESSIONS.length)];
                    sections.push(randomExpression);
                }
                if (enableGaze) {
                    const randomGaze = GAZES[Math.floor(Math.random() * GAZES.length)];
                    sections.push(randomGaze);
                }
            }

            if (hairFace) sections.push(hairFace);

            return sections.join(" ");
        }

        // NOTE: detail_1, detail_2, fit_pattern are NOT sent - only used for analysis

        // === GENERATION HELPER ===
        const generateOne = async (view: 'styling' | 'front' | 'side' | 'back') => {
            const reqData = buildStructuredPrompt(view);

            let finalRes = '1K';
            if (typeof resolution === 'string') {
                if (resolution.includes('2K')) finalRes = '2K';
                if (resolution.includes('4K')) finalRes = '4K';
            }

            const falPayload = {
                prompt: reqData.prompt,
                negative_prompt: reqData.negative_prompt,
                image_urls: reqData.input_images,
                aspect_ratio: aspectRatio,
                resolution: finalRes,
                seed: requestSeed,
                enable_web_search: enableWebSearch,
                output_format: "png"
            };

            const falKey = process.env.FAL_KEY;
            if (!falKey) throw new Error("FAL_KEY missing");

            const response = await fetch("https://fal.run/fal-ai/nano-banana-pro/edit", {
                method: "POST",
                headers: {
                    "Authorization": `Key ${falKey}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(falPayload),
            });

            if (!response.ok) {
                const err = await response.text();
                throw new Error(`Fal API Error (${view}): ${err}`);
            }
            const data = await response.json();
            return data.images?.[0]?.url;
        };

        // === PREVIEW MODE ===
        if (preview) {
            if (isAngles) {
                // Check if targetView is specified (Single Angle Mode)
                if (targetView) {
                    const promptData = buildStructuredPrompt(targetView);
                    return NextResponse.json({
                        status: "preview",
                        previews: [{
                            title: `${targetView.charAt(0).toUpperCase() + targetView.slice(1)} View`,
                            prompt: promptData.prompt,
                            structured: promptData.structured,
                            assets: promptData.input_images,
                            settings: { resolution, aspect_ratio: aspectRatio }
                        }]
                    });
                }

                // Return ALL 3 PROMPTS for 3-Angle Mode
                const frontData = buildStructuredPrompt('front');
                const sideData = buildStructuredPrompt('side');
                const backData = buildStructuredPrompt('back');

                return NextResponse.json({
                    status: "preview",
                    previews: [
                        {
                            title: "Front View",
                            prompt: frontData.prompt,
                            structured: frontData.structured,
                            assets: frontData.input_images,
                            settings: { resolution, aspect_ratio: aspectRatio }
                        },
                        {
                            title: "Side View",
                            prompt: sideData.prompt,
                            structured: sideData.structured,
                            assets: sideData.input_images,
                            settings: { resolution, aspect_ratio: aspectRatio }
                        },
                        {
                            title: "Back View",
                            prompt: backData.prompt,
                            structured: backData.structured,
                            assets: backData.input_images,
                            settings: { resolution, aspect_ratio: aspectRatio }
                        }
                    ]
                });
            } else {
                // Normal Styling Mode
                const reqData = buildStructuredPrompt(targetView || 'styling');
                return NextResponse.json({
                    status: "preview",
                    previews: [{
                        title: targetView ? `${targetView.charAt(0).toUpperCase() + targetView.slice(1)} View` : "Styling Shot",
                        prompt: reqData.prompt,
                        structured: reqData.structured,
                        assets: reqData.input_images,
                        settings: { resolution, aspect_ratio: aspectRatio }
                    }]
                });
            }
        }

        // === EXECUTION ===
        let results: { url: string, prompt: string }[] = [];

        if (isAngles) {
            if (targetView) {
                // SINGLE VIEW MODE
                const url = await generateOne(targetView as any);
                if (url) results.push({ url, prompt: "3-Angle View" });
            } else {
                // ALL 3 VIEWS
                const [frontUrl, sideUrl, backUrl] = await Promise.all([
                    generateOne('front'),
                    generateOne('side'),
                    generateOne('back')
                ]);
                if (frontUrl) results.push({ url: frontUrl, prompt: "Front View" });
                if (sideUrl) results.push({ url: sideUrl, prompt: "Side View" });
                if (backUrl) results.push({ url: backUrl, prompt: "Back View" });
            }
        } else {
            // Styling View
            const viewType = targetView || 'styling';
            const reqData = buildStructuredPrompt(viewType as any);
            const finalPrompt = reqData.prompt;
            const url = await generateOne(viewType as any);
            if (url) results.push({ url, prompt: finalPrompt });
        }

        return NextResponse.json({
            status: "completed",
            images: results.map(r => r.url),
            prompts: results.map(r => r.prompt)
        });

    } catch (error: any) {
        console.error("Generation error:", error);
        return NextResponse.json({ error: error.message || "Internal Server Error" }, { status: 500 });
    }
}
