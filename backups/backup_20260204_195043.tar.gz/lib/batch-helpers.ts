// Batch Generation Helper Functions for Photoshoot

export interface BatchSpec {
    view: string;
    pose: string;
    dynamic: boolean;
    lookAtCamera: boolean;
    hairBehind: boolean;
    camera: {
        shot_type: string;
        framing: string;
        angle: string;
    };
    assets: string[]; // 'front', 'back', or both
    fitDescriptionMode?: 'full' | 'first_sentence_only'; // Control fit description length
    excludeHairInfo?: boolean; // Exclude hair info from prompt
    excludeSocksInfo?: boolean; // Exclude socks info from prompt
    excludeShoesAsset?: boolean; // Don't send shoes asset to API
    enableWind?: boolean; // NEW: Subtle airflow toggle
    isStyling?: boolean; // NEW: Flag to identify styling shots
    includeGlasses?: boolean; // NEW: Only include glasses for specific shots
    useStickman?: boolean; // NEW: Only use stickman for specific shots
}

interface SavedPose {
    // ... existing SavedPose ...
}

export function buildBatchSpecs(
    workflowType: 'upper' | 'lower' | 'dress' | 'set',
    upperFraming: 'full' | 'medium_full',
    poseLibraryPrompt: string | null,
    hairBehindShoulders: boolean,
    genderVal: 'male' | 'female',
    savedPoses: SavedPose[],
    angledPosePrompt: string | null,
    enableWind: boolean
): BatchSpec[] {
    const getRandomPose = (type: 'random' | 'angled'): string => {
        // ... existing implementation ...
        const poses = type === 'random'
            ? (genderVal === 'female'
                ? ["Standing with one hand on hip, weight shifted to left leg", "Hands in pockets, relaxed stance", "Arms crossed casually", "One hand touching hair"]
                : ["Standing with hands in pockets, shoulders relaxed", "Arms at sides, weight on one leg", "One hand in pocket, other relaxed", "Hands clasped in front"])
            : (genderVal === 'female'
                ? ["Body rotated 45 degrees to the right, looking over shoulder", "Three-quarter turn to the left, hands on hips", "Slight rotation showing side profile"]
                : ["Body rotated 45 degrees to the right, looking at camera", "Three-quarter turn to the left, hands in pockets", "Slight rotation showing side profile"]);
        return poses[Math.floor(Math.random() * poses.length)];
    };

    if (workflowType === 'upper') {
        return [
            // 1. Styling Front
            {
                view: "styling_front",
                pose: poseLibraryPrompt || getRandomPose('random'),
                dynamic: true,
                lookAtCamera: true,
                hairBehind: hairBehindShoulders,
                camera: { shot_type: 'full_body', framing: 'head_to_toe', angle: "front" },
                assets: ['front'],
                fitDescriptionMode: 'full',
                enableWind: enableWind,
                isStyling: true,
                includeGlasses: true, // Only for first styling shot
                useStickman: true // ONLY for the first shot
            },
            // ... rest of the array (no useStickman: true)

            // 2. Styling Angled
            {
                view: "styling_angled",
                pose: angledPosePrompt || getRandomPose('angled'),
                dynamic: true,
                lookAtCamera: false,
                hairBehind: hairBehindShoulders,
                camera: { shot_type: 'full_body', framing: 'head_to_toe', angle: "angled" },
                assets: ['front', 'back'],
                fitDescriptionMode: 'full',
                enableWind: enableWind,
                isStyling: true
            },
            // 3. Styling Front (Second Pose from Library)
            {
                view: "styling_front_2",
                pose: poseLibraryPrompt || getRandomPose('random'),
                dynamic: true,
                lookAtCamera: true,
                hairBehind: hairBehindShoulders,
                camera: { shot_type: 'full_body', framing: 'head_to_toe', angle: "front" },
                assets: ['front'],
                fitDescriptionMode: 'full',
                enableWind: enableWind,
                isStyling: true
            },
            // 4. Technical Back (Cowboy Shot - Only technical shot)
            {
                view: "technical_back",
                pose: "Standing straight, back to camera, arms relaxed at sides. Professional studio photography.",
                dynamic: false,
                lookAtCamera: false,
                hairBehind: true,
                camera: { shot_type: 'cowboy_shot', framing: 'cowboy_shot', angle: "back" },
                assets: ['back'],
                fitDescriptionMode: 'full',
                excludeHairInfo: true,
                isStyling: false
            },
            // 5. Close-Up Front (Face to Chest)
            {
                view: "closeup_front",
                pose: "Close-up fashion photography shot, focusing on the collar and face area. Neutral expression, direct eye contact.",
                dynamic: false,
                lookAtCamera: true,
                hairBehind: hairBehindShoulders,
                camera: { shot_type: 'close_up', framing: 'chest_and_face', angle: "front" },
                assets: ['front'],
                fitDescriptionMode: 'full',
                isStyling: false
            }
        ];
    } else {
        // LOWER BODY / DRESS / SET
        return [
            // 1. Styling Front
            {
                view: "styling_front",
                pose: poseLibraryPrompt || getRandomPose('random'),
                dynamic: true,
                lookAtCamera: true,
                hairBehind: hairBehindShoulders,
                camera: { shot_type: 'full_body', framing: 'head_to_toe', angle: "front" },
                assets: ['front'],
                fitDescriptionMode: 'full',
                enableWind: enableWind,
                isStyling: true,
                includeGlasses: true, // Only for first styling shot
                useStickman: true // ONLY for the first shot
            },
            // 2. Styling Angled
            {
                view: "styling_angled",
                pose: angledPosePrompt || getRandomPose('angled'),
                dynamic: true,
                lookAtCamera: false,
                hairBehind: hairBehindShoulders,
                camera: { shot_type: 'full_body', framing: 'head_to_toe', angle: "angled" },
                assets: ['front', 'back'],
                fitDescriptionMode: 'full',
                enableWind: enableWind,
                isStyling: true
            },
            // 3. Technical Front
            {
                view: "technical_front",
                pose: "Standing straight, arms at sides, neutral stance. Professional studio photography.",
                dynamic: false,
                lookAtCamera: true,
                hairBehind: true,
                camera: { shot_type: 'full_body', framing: 'head_to_toe', angle: "front" },
                assets: ['front'],
                fitDescriptionMode: 'full',
                isStyling: false
            },
            // 4. Technical Back
            {
                view: "technical_back",
                pose: "Standing straight, back to camera, arms at sides. Professional studio photography.",
                dynamic: false,
                lookAtCamera: false,
                hairBehind: true,
                camera: { shot_type: 'full_body', framing: 'head_to_toe', angle: "back" },
                assets: ['back'],
                fitDescriptionMode: 'full',
                excludeHairInfo: true,
                isStyling: false
            },
            // 5. Detail Front
            {
                view: "detail_front",
                pose: "Close-Up fashion photography detail shot. Camera framing is waist-to-knees. Standing straight.",
                dynamic: false,
                lookAtCamera: true,
                hairBehind: true,
                camera: { shot_type: 'close_up', framing: 'waist_to_above_knees', angle: "front" },
                assets: ['front'],
                fitDescriptionMode: 'first_sentence_only',
                excludeHairInfo: true,
                excludeSocksInfo: true,
                excludeShoesAsset: true,
                isStyling: false
            },
            // 6. Detail Back
            {
                view: "detail_back",
                pose: "Close-Up fashion photography back detail shot. Camera framing is waist-to-knees. Standing straight, back to camera.",
                dynamic: false,
                lookAtCamera: false,
                hairBehind: true,
                camera: { shot_type: 'close_up', framing: 'waist_to_above_knees', angle: "back" },
                assets: ['back'],
                fitDescriptionMode: 'first_sentence_only',
                excludeHairInfo: true,
                excludeSocksInfo: true,
                excludeShoesAsset: true,
                isStyling: false
            }
        ];
    }
}

export async function extractDominantColor(imageUrl: string): Promise<string> {
    try {
        const geminiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
        if (!geminiKey) {
            console.warn("GEMINI_API_KEY missing, using fallback color");
            return "#8B4513";
        }

        // Fetch image and convert to base64
        const imageRes = await fetch(imageUrl);
        const imageBlob = await imageRes.blob();
        const base64Image = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(imageBlob);
        });

        const { GoogleGenerativeAI } = await import("@google/generative-ai");
        const genAI = new GoogleGenerativeAI(geminiKey);
        const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });

        const result = await model.generateContent([
            "Analyze this garment image and extract the DOMINANT color of the main product (not background, not model skin). Return ONLY a hex color code in format #RRGGBB. Example: #2E5C8A",
            {
                inlineData: {
                    data: base64Image,
                    mimeType: imageBlob.type
                }
            }
        ]);

        const response = await result.response;
        const text = response.text().trim();
        const hexMatch = text.match(/#[0-9A-Fa-f]{6}/);
        return hexMatch ? hexMatch[0] : "#8B4513";
    } catch (e) {
        console.error("Color extraction error:", e);
        return "#8B4513";
    }
}

export function generateColorPaletteSVG(color: string, productCode: string): string {
    const svg = `<svg width="300" height="300" xmlns="http://www.w3.org/2000/svg"><rect width="300" height="300" fill="${color}"/><rect y="250" width="300" height="50" fill="rgba(0,0,0,0.6)"/><text x="150" y="275" text-anchor="middle" fill="white" font-size="16" font-weight="bold" font-family="Arial">${productCode}</text><text x="150" y="30" text-anchor="middle" fill="white" font-size="12" opacity="0.8">Color Palette</text><text x="150" y="50" text-anchor="middle" fill="white" font-size="14" font-weight="bold" font-family="monospace">${color.toUpperCase()}</text></svg>`;
    return `data:image/svg+xml;base64,${btoa(svg)}`;
}
